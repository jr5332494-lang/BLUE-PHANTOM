package com.bhotex.bluephantom

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 48, 32, 48)
            setBackgroundColor(0xFF071426.toInt())
        }
        val title = TextView(this).apply {
            text = "BLUE PHANTOM\nLIVE GIVEAWAY COMPANION"
            textSize = 25f
            setTextColor(0xFF55B8FF.toInt())
            gravity = Gravity.CENTER
            setPadding(8, 8, 8, 28)
        }
        val info = TextView(this).apply {
            text = "প্রথমে Display over other apps অনুমতি দিন। তারপর Free Fire চালু করে Floating Button ব্যবহার করুন।"
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            setPadding(8, 8, 8, 24)
        }
        val permission = Button(this).apply {
            text = "OVERLAY PERMISSION"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        }
        val start = Button(this).apply {
            text = "START FLOATING OVERLAY"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    startService(Intent(this@MainActivity, OverlayService::class.java))
                } else {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                }
            }
        }
        val stop = Button(this).apply {
            text = "STOP OVERLAY"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        }
        layout.addView(title); layout.addView(info)
        layout.addView(permission); layout.addView(start); layout.addView(stop)
        setContentView(layout)
    }
}
