package com.bhotex.bluephantom

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*
import kotlin.random.Random

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private val names = mutableListOf<String>()
    private val prizes = listOf("25 Diamonds", "50 Diamonds", "100 Diamonds",
        "Weekly Membership", "Monthly Membership", "Level Up Pass",
        "Booyah Pass", "Special Offer", "Rare Gift")
    private val blue = 0xFF087BCE.toInt()
    private val dark = 0xEE071426.toInt()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    private fun params(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    )

    private fun showBubble() {
        val b = TextView(this).apply {
            text = "BP"
            textSize = 17f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            setBackgroundColor(blue)
            setPadding(18, 14, 18, 14)
            setOnClickListener { if (panel == null) showPanel() else closePanel() }
        }
        bubble = b
        val p = params(-2, -2).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 18; y = 240
        }
        wm.addView(b, p)
        b.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
            var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                val lp = b.layoutParams as WindowManager.LayoutParams
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        sx=e.rawX; sy=e.rawY; ox=lp.x; oy=lp.y; moved=false; return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx=(e.rawX-sx).toInt(); val dy=(e.rawY-sy).toInt()
                        if (kotlin.math.abs(dx)+kotlin.math.abs(dy)>8) moved=true
                        lp.x=ox-dx; lp.y=oy+dy; wm.updateViewLayout(b,lp); return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) { if (panel == null) showPanel() else closePanel() }
                        return true
                    }
                }
                return false
            }
        })
    }

    private fun showPanel() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 16, 18, 16)
            setBackgroundColor(dark)
        }
        val heading = TextView(this).apply {
            text = "BLUE PHANTOM  •  GIVEAWAY"
            textSize = 18f; setTextColor(0xFF65C5FF.toInt())
        }
        val entry = EditText(this).apply {
            hint = "Participant name"; setSingleLine(true)
            setTextColor(-1); setHintTextColor(0xFFB0BEC5.toInt())
        }
        val add = Button(this).apply {
            text = "ADD APPROVED ENTRY"
            setOnClickListener {
                val n = entry.text.toString().trim()
                if (n.isNotEmpty() && !names.contains(n)) {
                    names.add(n); entry.setText(""); status.text = "Entries: ${names.size}"
                }
            }
        }
        val status = TextView(this).apply {
            text = "Entries: ${names.size}"; textSize = 14f; setTextColor(-1)
        }
        val draw = Button(this).apply {
            text = "SELECT RANDOM WINNER"
            setOnClickListener {
                if (names.isEmpty()) {
                    status.text = "আগে Mission যাচাই করে নাম যোগ করুন"
                } else {
                    val winner = names.random()
                    names.remove(winner)
                    val prize = prizes.random()
                    status.text = "WINNER: $winner\nPRIZE: $prize\nEntries left: ${names.size}"
                }
            }
        }
        val close = Button(this).apply {
            text = "MINIMIZE"
            setOnClickListener { closePanel() }
        }
        box.addView(heading); box.addView(entry); box.addView(add)
        box.addView(status); box.addView(draw); box.addView(close)
        panel = box
        val p = params(760.coerceAtMost(resources.displayMetrics.widthPixels - 32), -2).apply {
            gravity = Gravity.CENTER
            flags = flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        }
        wm.addView(box, p)
    }

    private fun closePanel() {
        panel?.let { wm.removeView(it) }; panel = null
    }

    override fun onDestroy() {
        closePanel()
        bubble?.let { wm.removeView(it) }; bubble = null
        super.onDestroy()
    }
}
